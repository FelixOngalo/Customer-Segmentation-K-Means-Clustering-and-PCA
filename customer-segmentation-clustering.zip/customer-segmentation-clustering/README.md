# Customer Segmentation: K-Means Clustering and PCA

**Question:** *(fill in)* What natural customer segments does the data itself reveal, without imposing a predefined rule like RFM quartiles?

**Key findings:** *(fill in after running; how many segments, one line describing each, and your top recommendation)*

**Tools:** R, k-means clustering, PCA, tidyverse, Quarto

## Why this project — and how it differs from the portfolio's other segmentation work

Two other projects in this portfolio already segment customers: RFM quartiles (`sales-analytics-dashboard`) and a probabilistic CLV forecast (`clv-forecasting`). This one is conceptually different from both: instead of applying a predefined rule (quartile cutoffs) or forecasting a future number, **unsupervised clustering lets the data determine both how many groups exist and what separates them.** This can surface segments a fixed rule would blur together — for example, a "frequent but low-spend" group and a "rare but high-spend" group that plain RFM quartiles might lump into the same middle tier.

## Reproduce

1. Download "Online Retail II" to `data/raw/online_retail_II.xlsx` (see `R/00_get_data.R`) — reuse the file from earlier projects if you already have it
2. `install.packages(c("tidyverse", "janitor", "readxl", "scales", "quarto"))`
3. Run in order:
   - `R/01_clean.R`
   - `R/02_cluster.R` (builds features, runs the elbow method, fits k-means, runs PCA for visualization)
   - Render `reports/report.qmd`

## Method in brief

1. **Engineer behavioral features per customer**: recency, frequency, monetary total, average order value, product variety, basket size, and tenure — a broader set than plain RFM, chosen deliberately (see `R/segmentation_functions.R` for the reasoning).
2. **Scale every feature** to mean 0, SD 1. This is not optional: k-means measures distance, and an unscaled "total spend" column would dominate a "number of orders" column purely because its raw numbers are bigger.
3. **Choose k with the elbow method**: run k-means across a range of k values, plot within-cluster variance against k, and look for where the improvement from adding another cluster flattens out. This is a judgment call, not an automatic answer.
4. **Fit k-means** at the chosen k.
5. **Use PCA for visualization only**: reduce the 7-dimensional feature space to 2 principal components so the clusters can be plotted on an ordinary scatterplot. The clustering itself runs on the full feature set — PCA is a window into the result, not part of the clustering method.
6. **Profile and name each segment** by un-scaling the cluster centers back into real units (dollars, days, order counts) and describing what distinguishes each group in plain language a business stakeholder would understand.

## Key concepts

| Concept | Plain-English meaning |
|---|---|
| K-means clustering | Groups data points into k clusters by minimizing distance within each cluster |
| Feature scaling | Standardizing variables to comparable ranges, so no single feature dominates the distance calculation purely due to its units |
| Elbow method | Plotting within-cluster variance against k to visually judge a reasonable number of clusters |
| nstart | Re-running k-means from several random starting points and keeping the best result, since a single run can converge to a worse local optimum |
| PCA (Principal Component Analysis) | Finds the directions of greatest variance in the data, used here to visualize high-dimensional clusters in 2D |
| Cluster center | The average feature values of a cluster's members — the basis for naming and interpreting each segment |

## Project structure

```
R/00_get_data.R                data source notes
R/cleaning.R                    cleaning function
R/01_clean.R                     run cleaning
R/segmentation_functions.R        feature engineering, scaling, elbow method, cluster interpretation (heavily commented)
R/02_cluster.R                     run feature building, elbow method, k-means, PCA
reports/report.qmd                 full write-up: features, elbow plot, segment profiles, PCA visualization, recommendations
```

## Limitations

*(fill in — see the report's own Limitations section: k-means' spherical-cluster assumption, judgment call on k, feature-set sensitivity)*
