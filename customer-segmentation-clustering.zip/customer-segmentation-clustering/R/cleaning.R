library(dplyr)
library(janitor)
library(lubridate)

clean_orders <- function(raw) {
  raw |>
    clean_names() |>
    rename(any_of(c(
      invoice_no   = "invoice",
      customer_id  = "customer_id",
      invoice_date = "invoicedate",
      quantity     = "quantity",
      unit_price   = "price"
    ))) |>
    mutate(
      invoice_date = as_date(invoice_date),
      is_cancelled = grepl("^C", as.character(invoice_no)),
      revenue      = quantity * unit_price
    ) |>
    filter(
      !is.na(customer_id),
      !is_cancelled,
      quantity > 0,
      unit_price > 0
    )
}
