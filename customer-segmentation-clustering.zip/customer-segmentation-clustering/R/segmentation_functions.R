# Reusable functions for behavioral customer segmentation via k-means
# clustering, with PCA used for both dimensionality reduction and
# visualization. This is a different technique than RFM quartiles
# (sales-analytics-dashboard) or BG/NBD forecasting (clv-forecasting):
# instead of a pre-defined rule (quartile cutoffs) or a forecast, this
# lets the DATA itself reveal how many natural groups of customers
# exist and what distinguishes them.

library(dplyr)
library(tidyr)

#' Build per-customer behavioral features for clustering.
#'
#' Clustering is sensitive to WHICH features you feed it -- unlike RFM,
#' there's no fixed formula, so this is a deliberate design choice.
#' We use a broader feature set than plain RFM to let the clusters
#' reveal distinctions (e.g. breadth of purchases, weekend vs weekday
#' shopping) that a 3-variable RFM model can't see.
#'
#' @param orders Cleaned order-level data.
#' @param observation_end Reference date for recency; defaults to the max date in the data.
#' @return A tibble of customer_id plus numeric behavioral features.
build_customer_features <- function(orders, observation_end = NULL) {
  if (is.null(observation_end)) observation_end <- max(orders$invoice_date)

  orders |>
    group_by(customer_id) |>
    summarise(
      recency_days      = as.numeric(observation_end - max(invoice_date)),
      frequency_orders  = n_distinct(invoice_no),
      monetary_total    = sum(revenue),
      avg_order_value   = monetary_total / frequency_orders,
      item_variety      = n_distinct(description),
      avg_basket_size    = sum(quantity) / frequency_orders,
      tenure_days         = as.numeric(max(invoice_date) - min(invoice_date)),
      .groups = "drop"
    ) |>
    filter(monetary_total > 0, frequency_orders > 0)
}

#' Prepare a feature matrix for k-means: scale every column to mean 0,
#' sd 1. This step is NOT optional for k-means -- the algorithm uses
#' Euclidean distance, and an unscaled "monetary_total" column (which
#' might range into the thousands) would completely dominate a
#' "frequency_orders" column (which might range from 1 to 20), making
#' the clustering effectively ignore every feature except the one with
#' the largest raw numbers.
#'
#' @param features A tibble from build_customer_features().
#' @return A list: scaled matrix (customer_id as rownames) and the
#'   scaling center/scale vectors (needed to un-scale cluster centers
#'   later for interpretation).
scale_features <- function(features) {
  feature_cols <- features |> select(-customer_id)
  scaled <- scale(feature_cols)

  list(
    matrix     = scaled,
    customer_id = features$customer_id,
    center      = attr(scaled, "scaled:center"),
    scale       = attr(scaled, "scaled:scale")
  )
}

#' Run k-means for a range of k values and collect the within-cluster
#' sum of squares for each -- the data behind an "elbow plot", the
#' standard (if imperfect) way to pick a reasonable number of clusters
#' without just guessing.
#'
#' @param scaled_matrix The scaled feature matrix from scale_features().
#' @param k_range Vector of k values to try.
#' @param nstart Number of random starting configurations per k (k-means
#'   can converge to a different local optimum depending on its random
#'   start, so nstart > 1 reruns it and keeps the best result).
#' @return A tibble: k, total within-cluster sum of squares.
elbow_data <- function(scaled_matrix, k_range = 2:10, nstart = 25) {
  purrr::map_dfr(k_range, function(k) {
    km <- kmeans(scaled_matrix, centers = k, nstart = nstart)
    tibble::tibble(k = k, tot_withinss = km$tot.withinss)
  })
}

#' Un-scale cluster centers back to the original feature units, so
#' they're interpretable ("Cluster 2 averages $450 spend, 3 orders")
#' instead of meaningless standardized values ("Cluster 2: 1.2, -0.3...").
#'
#' @param km A fitted kmeans object.
#' @param scale_info The list returned by scale_features().
#' @return A tibble of cluster centers in original units.
unscale_centers <- function(km, scale_info) {
  centers_scaled <- km$centers
  sweep(centers_scaled, 2, scale_info$scale, `*`) |>
    sweep(2, scale_info$center, `+`) |>
    as_tibble() |>
    mutate(cluster = row_number(), size = as.integer(table(km$cluster)), .before = 1)
}
