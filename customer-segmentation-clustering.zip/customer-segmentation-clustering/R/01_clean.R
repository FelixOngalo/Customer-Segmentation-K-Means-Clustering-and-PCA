library(readxl)
library(dplyr)
source("R/cleaning.R")

raw   <- read_excel("data/raw/online_retail_II.xlsx")
clean <- clean_orders(raw)

cat("Rows before:", nrow(raw), "\n")
cat("Rows after: ", nrow(clean), "\n")
cat("Customers:  ", n_distinct(clean$customer_id), "\n")

saveRDS(clean, "data/clean/orders_clean.rds")
