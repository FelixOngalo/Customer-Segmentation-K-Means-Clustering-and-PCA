# Data: reuse "Online Retail II" (same dataset as the sales-analytics-
# dashboard, market-basket-analysis, and clv-forecasting projects) --
# transaction-level data, which we'll aggregate to one row per customer
# with behavioral features for clustering.
#   https://archive.ics.uci.edu/dataset/502/online+retail+ii
# Download the XLSX and place it at data/raw/online_retail_II.xlsx
# (reuse the file from earlier projects if you already have it).
message("Download Online Retail II to data/raw/online_retail_II.xlsx (reuse from earlier projects if you already have it)")
