library(dplyr)
library(purrr)
source("R/segmentation_functions.R")

orders <- readRDS("data/clean/orders_clean.rds")

features <- build_customer_features(orders)
cat("Customers with features built:", nrow(features), "\n")

scale_info <- scale_features(features)

# --- Choose k: elbow method ---
# As k increases, within-cluster variance always decreases (more
# clusters can always fit the data better) -- so we're not looking for
# a minimum, we're looking for the point where adding another cluster
# stops buying much improvement ("the elbow").
elbow <- elbow_data(scale_info$matrix, k_range = 2:10)
saveRDS(elbow, "data/clean/elbow_data.rds")
print(elbow)

# Pick k -- inspect the elbow plot in the report before finalizing this.
# A starting default; override after looking at the chart.
chosen_k <- 4

set.seed(42)
km <- kmeans(scale_info$matrix, centers = chosen_k, nstart = 25)

# --- PCA for visualization ---
# k-means ran on ALL the scaled features (7-dimensional), which can't
# be plotted directly. PCA finds the 2 directions (principal components)
# that capture the most variance in the data, so clusters can be seen
# on a normal 2D scatterplot -- this is purely for visualization; the
# clustering itself was NOT done on the PCA-reduced data.
pca <- prcomp(scale_info$matrix)
var_explained <- summary(pca)$importance[2, 1:2]
cat("\nVariance explained by PC1 + PC2:", round(sum(var_explained) * 100, 1), "%\n")

pca_coords <- as_tibble(pca$x[, 1:2]) |>
  mutate(customer_id = scale_info$customer_id, cluster = factor(km$cluster))

cluster_profile <- unscale_centers(km, scale_info)
print(cluster_profile)

results <- features |>
  mutate(cluster = factor(km$cluster))

saveRDS(list(
  features = results, km = km, pca = pca, pca_coords = pca_coords,
  cluster_profile = cluster_profile, var_explained = var_explained,
  chosen_k = chosen_k, elbow = elbow
), "data/clean/cluster_results.rds")
